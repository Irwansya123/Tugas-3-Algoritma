/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scanner;

import java.util.Scanner;

/**
 *
 * @author IRWAN SYARIF
 */
public class MenghitungVolumeBola {
    public static void main(String[] args){
        Scanner scan =new Scanner(System.in);
        double volume, r;
        
        System.out.print("Nilai r =");
        r = Double.valueOf(scan.nextLine());
        
        volume = 0.4/0.3*3.14*r*r*r;
        System.out.println("Volume bola adalah ="+volume);
        
        //r=jari-jari
        
    }
            
            
}

    
    

