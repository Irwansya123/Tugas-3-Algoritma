/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scanner;

import java.util.Scanner;

/**
 *
 * @author IRWAN SYARIF
 */
public class MenghitungLuasBalok {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        int luas, p, l, t;
        
        System.out.print("Inputkan nilai p =");
        p = Integer.parseInt(scan.nextLine());
      
        System.out.print("Inputkan nilai l =");
        l = Integer.parseInt(scan.nextLine());
      
        System.out.print("Inputkan nilai t =");
        t = Integer.parseInt(scan.nextLine());
        
        luas = 2*p*l+2*l*t+2*p*t;
        System.out.println("Hasil luas balok ="+luas);
        
        //p=panjang
        //l=lebar
        //t=tinggi
        
    }
    
}



    
