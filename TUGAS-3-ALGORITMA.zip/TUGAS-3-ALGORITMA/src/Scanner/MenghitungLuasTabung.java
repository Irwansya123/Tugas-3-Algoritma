/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scanner;

import java.util.Scanner;

/**
 *
 * @author IRWAN SYARIF
 */
public class MenghitungLuasTabung {
    public static void main(String[] args){
        Scanner scan =new Scanner(System.in);
        double luas, r;
        
        System.out.print("Inputkan nilai r =");
        r = Double.valueOf(scan.nextLine());
        
        luas = 2*3.14*r*r;
        System.out.println("Hasil luas bola ="+luas);
        
        //r=jari-jari
        
}

}
    


    

